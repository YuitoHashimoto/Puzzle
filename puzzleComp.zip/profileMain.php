<main class="main" id="profileMain">
    <div class="main__content">
        <p class="main__content__text">
            得意なこと<br>
            HTML,CSS,JS
        </p>
        <p class="main__content__text">
            資格<br>
            英検3級
        </p>
    </div>
</main>
